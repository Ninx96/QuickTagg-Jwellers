const font = {
  regular: "ElMessiri-regular",
  medium: "ElMessiri-medium",
  bold: "ElMessiri-bold",
};

export default font;
