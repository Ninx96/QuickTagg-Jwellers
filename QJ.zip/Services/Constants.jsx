export const serviceUrl = "https://jewellerapi.quickgst.in/api/";

export const authUrl = "https://jewellerapi.quickgst.in/auth/";
