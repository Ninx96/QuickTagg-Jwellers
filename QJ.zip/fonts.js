const font = {
    regular: 'nunito-regular',
    medium: 'nunito-medium',
    bold: 'nunito-bold'
  }


  export default font;